import * as React from "react";
import * as ReactDOM from "react-dom";
// import {ReactDOM} from "./CONST";
import "./index.css";
import jsx from "./pages/ExamplePage";
// import SetStatePage from "./pages/SetStatePage";

ReactDOM.render(jsx, document.getElementById("root"));
console.log("React", React.version); //sy-log
