// import * as React from "react";
// import {useState, Component} from "react";
// import * as ReactDOM from "react-dom";

import ReactDOM, {useState} from "./kreact/react-dom";
import Component from "./kreact/Component";

export {ReactDOM, useState, Component};
