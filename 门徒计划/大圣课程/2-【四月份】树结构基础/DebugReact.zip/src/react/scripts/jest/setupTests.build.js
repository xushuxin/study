'use strict';

jest.mock('scheduler', () => require.requireActual('scheduler/unstable_mock'));
