module.exports = require('./dist/standalone');
