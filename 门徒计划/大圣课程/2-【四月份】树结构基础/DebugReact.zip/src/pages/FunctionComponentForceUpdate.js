import {useCallback, useReducer, useState} from "react";

export default function FunctionComponentForceUpdate(props) {
  console.log("omg"); //sy-log
  // ! 方法1：useReducer
  // const [, forceUpdate] = useReducer((x) => x + 1, 0);
  // ! 方法2：useState
  const [count, forceUpdate] = useState(0);

  const handleClick = useCallback(() => {
    // forceUpdate();
    forceUpdate((prev) => prev + 1);
  });
  // ! 方法3：抽取自定义hook

  return (
    <div>
      <h3>函数组件中的forceUpdate</h3>
      <button onClick={handleClick}>click</button>
    </div>
  );
}

// hook只能用在函数组件或者是自定义hook
function useForceUpdate() {
  const [state, setState] = useState(0);
  const update = useCallback(() => {
    setState((prev) => prev + 1);
  }, []);

  return update;
}
